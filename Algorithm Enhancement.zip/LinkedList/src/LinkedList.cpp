//============================================================================
// Name        : LinkedList.cpp
// Author      : Noah Jeleniewski
// Date        : 11/20/20
// Version     : 1.0
// Copyright   : Copyright © 2020 SNHU COCE
// Description : Linked List Refinement
//============================================================================

// Necessary includes
#include <algorithm>
#include <iostream>
#include <time.h>
#include "CSVparser.hpp" // Reference the CSVParser library
using namespace std;

// Global definitions visible to all methods and classes

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

// Linked-List class definition

// Define a class containing data members and methods to implement a linked-list.
class LinkedList {

private:
    // Internal structure for list entries, housekeeping variables
	struct Node {
		Bid bid;
		Node* next;

		// default constructor
		Node() {
			next = nullptr;
		}

		// initialize a node with a bid
		Node(Bid aBid) {
			bid = aBid;
			next = nullptr;
		}
	};

	Node* head;
	Node* tail;
	int size = 0;

public:
    LinkedList();
    virtual ~LinkedList();
    void Append(Bid bid);
    void Prepend(Bid bid);
    void PrintList();
    void Remove(string bidId);
    Bid Search(string bidId);
    int Size();
};


// Default constructor

LinkedList::LinkedList() {
    // Initialize housekeeping variables
	head = nullptr;
	tail = nullptr;
}

// Destructor
LinkedList::~LinkedList() {
}


// Append a new bid to the end of the list
void LinkedList::Append(Bid bid) {
    // Implement append logic
	Node* node = new Node(bid);

	if (head == nullptr) {
		head = node;
		tail = node;
	} else {
		if (tail != nullptr) {
			tail->next = node;
		}
	}

	// new node will always be the tail
	tail = node;
	// increment size
	size++;
}

// Prepend a new bid to the start of the list
void LinkedList::Prepend(Bid bid) {
    // Implement prepend logic
	Node* node = new Node(bid);

	if (head != nullptr) {
		node->next = head;
	}

	head = node;
	// increment size
	size++;
}

//Simple output of all bids in the list
void LinkedList::PrintList() {
    // Implement print logic
	Node* current = head;

	//loop over each node, looking for a match
	while (current != nullptr) {
		// prints out the list
		cout << current->bid.bidId << ": " << current->bid.title << " | "
			 << current->bid.amount << " | " << current->bid.fund << endl;
		current = current->next;
	}
}


/**Remove a specified bid
 * @param bidId The bid id to remove from the list
 * */
void LinkedList::Remove(string bidId) {
    // Implement remove logic
	Node* current = head;
	//loop over each node, looking for a match
	if (head != nullptr) {
		if (head->bid.bidId.compare(bidId) == 0) {
			Node* tempNode = head->next;
			delete head;
			head = tempNode;
		}
	}
	while (current->next != nullptr) {
		if (current->next->bid.bidId.compare(bidId) == 0) {
			// saves the next node (one to be removed)
			Node* tempNode = current->next;

			// make current node point beyond the next one (to be removed)
			current->next = tempNode->next;

			// delete temp node
			delete tempNode;
			// decrement size
			size--;
			return;
		}
		current = current->next;
	}

}


/**Search for the specified bidId
 * @param bidId The bid id to search for
 */
Bid LinkedList::Search(string bidId) { // @suppress("No return")
    // Implement search logic
	Node* current = head;

	//loop over each node, looking for a match
	while (current != nullptr) {
		if (current->bid.bidId.compare(bidId) == 0) {
			return current->bid;
		}
		current = current->next;
	}
}


// Returns the current size (number of elements) in the list
int LinkedList::Size() {
    return size;
}

// Static methods used for testing

/**Display the bid information
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
	// prints out the bid information
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount
         << " | " << bid.fund << endl;
    return;
}


/**Prompt user for bid information
 * @return Bid struct containing the bid info
 */
Bid getBid() {
    Bid bid;

    cout << "Enter Id: ";
    cin.ignore();
    getline(cin, bid.bidId);

    cout << "Enter title: ";
    getline(cin, bid.title);

    cout << "Enter fund: ";
    cin >> bid.fund;

    cout << "Enter amount: ";
    cin.ignore();
    string strAmount;
    getline(cin, strAmount);
    bid.amount = strToDouble(strAmount, '$');

    return bid;
}


/**Load a CSV file containing bids into a LinkedList
 * @return a LinkedList containing all the bids read
 */
void loadBids(string csvPath, LinkedList *list) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // initialize a bid using data from current row (i)
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            // add this bid to the end
            list->Append(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

/**Simple C function to convert a string to a double
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**Main Method
 * @param arg[1] path to CSV file to load from (optional)
 * @param arg[2] the bid Id to use when searching the list (optional)
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey, password, userPass;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        // Set default bidKey
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
    	// Default csv path
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98109";
    }

    clock_t ticks;
    LinkedList bidList;
    Bid bid;
    password = "Open"; // Set password

    int passwordAttempts = 3; // Number of attempts the user has
    bool loginSuccess = false;

    cout << "Enter the password (Case Sensitive): " << endl;
    while (passwordAttempts > 0 && loginSuccess == false) { // Loop to require password
    	cin >> userPass;
    	if (userPass != password) { // Input doesn't equal password
    		passwordAttempts--; // Decrement attempts
    		cout << "Incorrect password. You have " << passwordAttempts << " attempt(s) remaining." << endl; // Print attempts
    	}
    	else { // userPass == password
    		cout << "Correct! Welcome to the Main Menu..." << endl;
    		loginSuccess = true;
    	}
    }

    if (loginSuccess) { // If login is successful

    int choice = 0;
    while (choice != 9) {
    	// Main menu
        cout << "Menu:" << endl;
        cout << "  1. Enter a Bid" << endl;
        cout << "  2. Load Bids" << endl;
        cout << "  3. Display All Bids" << endl;
        cout << "  4. Find Bid" << endl;
        cout << "  5. Remove Bid" << endl;
        cout << "  6. Prepend a Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;


        switch (choice) {
        case 1:
        	// add a new bid
            bid = getBid();
            bidList.Append(bid);
            displayBid(bid);

            break;

        case 2:
        	// Clock
            ticks = clock();
            // Load the bids
            loadBids(csvPath, &bidList);

            cout << bidList.Size() << " bids read" << endl; // Display how many bids read

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " milliseconds" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 3:
        	// prints out current list
            bidList.PrintList();

            break;

        case 4:
            ticks = clock();
            cout << "Which bid would you like to find? (Search by ID)" << endl;
            cin >> bidKey;
            bid = bidList.Search(bidKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
            	cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 5:
        	// removes designated bid
        	cout << "Which bid would you like to remove? (Search by ID)" << endl;
        	cin >> bidKey;
        	bid = bidList.Search(bidKey);
            if (!bid.bidId.empty()) {
            	bidList.Remove(bidKey);
            	cout << "Bid Id " << bidKey << " removed." << endl;
            } else {
            	// if ID has already been removed/doesn't exist
            	cout << "Bid Id " << bidKey << " not found." << endl;
            }

            break;
        case 6:
        	// place bid in front
            bid = getBid();
            bidList.Prepend(bid);
            displayBid(bid);

            break;
        default:
        	break;
        }
    }
    // Program ends after this
    cout << "Good bye." << endl;

    return 0;
    }
    else {
    	cout << "Entered the wrong password too many times. Exiting program..." << endl; //Exit program if password attempts run out
    }
}

