/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit test verifies the relevant methods located
 * in the MedicalRecord.java class. It specifically verifies getPatient and
 * getHistory by creating variables for patient, name, id, and history, which are referenced
 * in the tests after creating a new 'medicalRecord'. 
*/
package medicalApplication.Model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.model.PatientHistory;

public class TestMedicalRecord {
	
	private MedicalRecord medicalRecord;
	private Patient patient;
	private PatientHistory history = new PatientHistory();
	private String name;
	private String id;
	
	//Setup necessary parameters
	@Before
	public void before() {
		this.name = "Olivia";
		this.id = "1000";
		this.patient = new Patient(name, id);
		this.medicalRecord = new MedicalRecord(patient);
		this.history = medicalRecord.getHistory();
	}
	
	@Test
	public void testGetPatient() {
		//Verify getPatient = patient
		assertTrue(medicalRecord.getPatient().equals(patient));
	}
	
	@Test
	public void testGetPatientHistory() {
		//Verify getHistory = history
		assertTrue(medicalRecord.getHistory().equals(history));
	}
	
}
