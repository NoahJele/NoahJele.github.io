/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit model test serves to test the relevant methods
 * located in PatientHistory.java. It's the most complicated model test in this
 * application, because there's a lot of setup that goes into making it work correctly.
 * First, I initiated relevant private variables and lists. Then, in @Before, I populated
 * these lists and added them, respectively. I then assigned each list using getAllTreatments,
 * getAllMedications, and getAlergies. In the addTreatment, addAllergy, and addMedication tests
 * I verified that the size of getAll*() was 1 to begin, since these were initially populated in @Before.
 * Then, I added another treatment, allergy, and medication to each test, and then tested the size again to 
 * ensure that it incremented. 
*/
package medicalApplication.Model;


import java.util.List;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.PatientHistory;
import medical.com.medicalApplication.model.Treatment;

public class TestPatientHistory {
	private PatientHistory history = new PatientHistory();
	private Treatment treatment;
    private Medication medication;
	private Allergy allergy;
	
	//Create lists for each relevant parameter
	private List<Treatment> treatments;
	private List<Medication> medications;
	private List<Allergy> allergies;
	
	//Setup necessary parameters
	@Before
	public void before() {
		this.treatment = new Treatment("6/7/20", "Hippopotomonstrosesquippedaliophobia", "Fear of long words");
		history.addTreatment(treatment);
		this.allergy = new Allergy("Cats");
		history.addAllergy(allergy);
		this.medication = new Medication("Xanax", "6/1/20", "7/1/20", "15mg");
		history.addMedication(medication);
		
		this.treatments = history.getAllTreatments();
		this.medications = history.getAllMedications();
		this.allergies = history.getAlergies();
	}
	
	@Test
	public void testAddTreatment() {
		//Verify size is 1 to start
		assertTrue(history.getAllTreatments().size() == 1);
		//Add new treatment
		this.treatment = new Treatment("6/9/20", "Acrophobia", "Fear of heights");
		history.addTreatment(treatment);
		//Verify size is now 2
		assertTrue(history.getAllTreatments().size() == 2);
		
	}
	
	@Test
	public void testAddMedication() {
		//Can't add medication IF treatment size = 0
		if (history.getAllTreatments().size() == 0) {
			fail("Can't add medication: No treatment has been added!");
		}
		//Verify size is 1 to start 
		assertTrue(history.getAllMedications().size() == 1);
		//Add new medication
		this.medication = new Medication("Ibuprofen", "6/20/20", "6/23/20", "2mg");
		history.addMedication(medication);
		//Verify size is now 2
		assertTrue(history.getAllMedications().size() == 2);
	}
	
	@Test
	public void testAddAllergy() {
		//Verify size is 1 to start
		assertTrue(history.getAlergies().size() == 1);
		//Add new Allergy
		this.allergy = new Allergy("Flowers");
		history.addAllergy(allergy);
		//Verify size is now 2
		assertTrue(history.getAlergies().size() == 2);	
	}
		
	@Test
	public void testGetAllTreatments() {
		//Verify all treatments equal the treatments list
		assertTrue(history.getAllTreatments().equals(treatments));
	}
	
	@Test
	public void testGetAllergies() {
		//Verify all allergies equal the allergies list
		assertTrue(history.getAlergies().equals(allergies));
	}
	
	@Test
	public void testGetAllMedications() {
		//Verify all medications equal the medications lists
		assertTrue(history.getAllMedications().equals(medications));
	}

}
