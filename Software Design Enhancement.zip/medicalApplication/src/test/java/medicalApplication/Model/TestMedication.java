/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit model test verifies the relevant methods located in 
 * Medication.java. Specifically, it ensures that the name, startDate, endDate, and dose variables
 * all return as expected into a Medication query. The variables are initiated and then defined in @Before,
 * and then are assigned to a new Medication, where they are then referenced throughout the tests. Then, they
 * are converted to string and verified to work correctly in that test as well.
 * BUG: In the Final Project Test plan, it says that " Medications cannot be assigned to a patient
 * history unless there has been a treatment first." When running the program, it does NOT stop the user
 * if they put in a Medication first.
*/
package medicalApplication.Model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Medication;

public class TestMedication {
	private Medication medication;
	private String name;
	private String startDate;
	private String endDate;
	private String dose;
	
	//Setup parameters before testing
	@Before
	public void before() {
		this.name = "Xanax";
		this.startDate = "6/1/20";
		this.endDate = "6/28/20";
		this.dose = "5mg";
		this.medication = new Medication(name, startDate, endDate, dose);
	}

	@Test
	public void testSetName() {
		//Verify name returns as 'Xanax'
		assertTrue(medication.getName().equalsIgnoreCase(name));
		assertFalse(medication.getName().equalsIgnoreCase("Test Drug"));
	}
	
	@Test
	public void testSetStartDate() {
		//Verify start date is '6/1/20'
		assertTrue(medication.getStartDate().equals(startDate));
		assertFalse(medication.getStartDate().equals("6/10/20"));
	}
	
	@Test
	public void testSetEndDate() {
		//Verify end date is '6/28/20'
		assertTrue(medication.getEndDate().equals(endDate));
		assertFalse(medication.getEndDate().equals("6/30/20"));
	}
	
	@Test
	public void testSetDose() {
		//Verify dose is '5mg'
		assertTrue(medication.getDose().equalsIgnoreCase(dose));
		assertFalse(medication.getDose().equalsIgnoreCase("10mg"));
	}
	
	@Test
	public void testToString() {
		//Verify everything converts to string correctly
		assertTrue(medication.toString().equals("Medication: " + name + " Start Date: " + startDate + " End Date: "+ endDate + " Dose: " + dose));
		assertFalse(medication.toString().equals("Medication : " + "Test Drug" + " Start Date: " + "6/10/20" + " End Date: " + "6/30/20" + " Dose: " + "10mg"));
	}

}
