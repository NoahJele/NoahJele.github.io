/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit model test serves to test the methods in
 * Doctor.java. Following best practices, it assigns values to the
 * name and ID variables, and then calls them for each test. These tests
 * verify correct names and IDs, and in the final test testToString(),
 * it verifies everything is converted to string correctly
 * MINOR BUG: Well, maybe not an explicit bug, but something that doesn't follow best practices
 * is the toString() method immediately displaying the name of the doctor after the 
 * first semi-colon. This is inconsistent with the other toString methods in the other model classes.
 * BUG: A bug located in Doctor.java is that createDoctor() method uses ==, when it should use .equals. Here's the updated line:
 * boolean createDoctor = !doctors.stream().anyMatch(doctor -> doctor.getId().equals(tempId));
 * This fixed the bug.
*/
package medicalApplication.Model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Doctor;

public class TestDoctor {
	private Doctor doctor;
	private String name;
	private String id;
	
	//Setup necessary parameters
	@Before
	public void before() {
		this.name = "Bob";
		this.id = "1000";
		this.doctor = new Doctor(name, id);
	}
	
	@Test
	public void testSetName() {
		//Make sure getName() returns Bob
		assertTrue(doctor.getName().equalsIgnoreCase(name));
		assertFalse(doctor.getName().equalsIgnoreCase("Bill"));

	}
	
	@Test
	public void testSetId() {
		//Verify getId() returns as 1000
		assertTrue(doctor.getId().equals(id));
		assertFalse(doctor.getId().equals("100"));
	}
	
	@Test
	public void testToString() {
		//Verify that everything converts to string correctly
		assertTrue(doctor.toString().equals("Doctor Name:" + name + " ID: " + id));
		assertFalse(doctor.toString().equals("Doctor Name:" + "Bill" + " ID: " + "100"));
	}

}
