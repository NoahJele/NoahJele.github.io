/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit model test serves to test all of the relevant methods
 * located in Treatment.java. There are tests for the treatment date, diagnosis, description,
 * and conversion to String. In the @Before section, these variables are defined and then applied
 * to a new Treatment, which is then referenced throughout the tests. Something to note is that 
 * the 'description' field isn't used in the toString() method. 
*/
package medicalApplication.Model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Treatment;

public class TestTreatment {
	private Treatment treatment;
	private String treatmentDate;
	private String diagnose;
	private String description;
	
	//Setup parameters before testing
	@Before
	public void before() {
		this.treatmentDate = "6/24/20";
		this.diagnose = "Headaches";
		this.description = "Daily migraines";
		this.treatment = new Treatment(treatmentDate, diagnose, description);
	}
	
	@Test
	public void testSetTreatmentDate() {
		//Verify treatment date is '6/24/20'
		assertTrue(treatment.getTreatmentDate().equals(treatmentDate));
		assertFalse(treatment.getTreatmentDate().equals("6/30/20"));
	}
	
	@Test
	public void testSetDiagnose() {
		//Verify diagnosis is 'Headaches
		assertTrue(treatment.getDiagnose().equalsIgnoreCase(diagnose));
		assertFalse(treatment.getDiagnose().equalsIgnoreCase("Splitting Headache"));		
	}

	@Test
	public void testSetDescription() {
		//Verify Description is 'Daily Migraines'
		assertTrue(treatment.getDescription().equalsIgnoreCase(description));
		assertFalse(treatment.getDescription().equalsIgnoreCase("Weekly Headaches"));
	}
	
	@Test
	public void testToString() {
		//Verify everything is converted to String correctly
		assertTrue(treatment.toString().equals("Treatment Date: " + treatmentDate + " Diagnose: " + diagnose + " Description: " + description));
		assertFalse(treatment.toString().equals("Treatment Date: " + "6/30/20" + " Diagnose: " + "Splitting Headache" + " Description: " + "Weekly Headaches"));
	}

}
