/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit model test verifies the relevant methods located
 * in Patient.java. Specifically, private name and id variables are initiated, and then
 * defined in @Before. These variables are then applied to a new Patient, which is then
 * referenced throughout the tests. 
*/
package medicalApplication.Model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Patient;

public class TestPatient {
	private Patient patient;
	private String name;
	private String id;
	
	//Setup parameters before testing
	@Before
	public void before() {
		this.name = "Sammy";
		this.id = "101";
		this.patient = new Patient(name, id);
	}
	
	@Test
	public void testSetName() {
		//Verify name is 'Sammy'
		assertTrue(patient.getName().equalsIgnoreCase(name));
		assertFalse(patient.getName().equalsIgnoreCase("Sam"));
	}
	
	@Test
	public void testSetId() {
		//Verify ID is '9000'
		assertTrue(patient.getId().equals(id));
		assertFalse(patient.getId().equals("900"));
	}

	@Test
	public void testToString() {
		//Verify everything converts to String correctly
		assertTrue(patient.toString().equals("Patient Name: " + name + " ID: " + id));
		assertFalse(patient.toString().equals("Patient Name: " + "Sam" + " ID: " + "900"));
	}

}
