/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit model test serves to test the relevant methods
 * located in Allergey.java. It creates a new allergey (Sneezing)
 * and then verifies that getName() = sneezing, and that it is converted
 * to string correctly.
 * MINOR BUG: Allergey.java is misnamed, and should be named Allergy.java instead to follow
 * consistent naming conventions. This is a minor bug, but one worth fixing.
 * BUG/MISSING FEATURE: In the Final Project Test Plan, it states "The system shall allow the user... 
 * to print all patients with allergies. This is NOT an option in the program (you can only search for a specific 
 * allergy, NOT print out ALL patients that have any allergy)
*/
package medicalApplication.Model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;

public class TestAllergy {
	private Allergy allergy;
	private String name;
	
	//Setup parameters before testing
	@Before
	public void before() {
		this.name = "Sneezing";
		this.allergy = new Allergy(name);
	}
	
	@Test
	public void testSetName() {
		//Verify allergey name is Sneezing
		assertTrue(allergy.getName().equalsIgnoreCase(name));
		assertFalse(allergy.getName().equalsIgnoreCase("Cold"));
	}
	
	@Test
	public void testToString() {
		//Verify allergy name is converted to String correctly
		assertTrue(allergy.toString().equals("Allergy " + name));
		assertFalse(allergy.toString().equals("Allergy " + "Cold"));
	}	

}
