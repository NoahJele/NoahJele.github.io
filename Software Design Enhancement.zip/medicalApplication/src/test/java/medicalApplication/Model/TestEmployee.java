/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit model test verifies the methods located
 * in Employee.java. Specifically, it verifies that the correct name, 
 * ID, and password. Lastly, testGetPassword() specifically makes sure that "Open"
 * verifies as true and that 'open' verifies as false because the password is case sensitive.
*/
package medicalApplication.Model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Employee;

public class TestEmployee {
	private Employee employee;
	private String name;
	private String id;
	private String password;
	
	//Setup parameters before testing
	@Before
	public void before() {
		this.name = "Noah";
		this.id = "1234";
		this.password = "Open";
		this.employee = new Employee(name, id);
	}
	
	@Test
	public void testGetName() {
		//Verify name returns 'Noah'
		assertTrue(employee.getName().equalsIgnoreCase(name));
		assertFalse(employee.getName().equalsIgnoreCase("Nick"));
	}
	
	@Test
	public void testGetId() {
		//Verify ID returns '1234'
		assertTrue(employee.getId().equals(id));
		assertFalse(employee.getId().equals("4321"));
	}
	
	@Test
	public void testGetPassword() {
		//Verify password is 'Open'
		assertTrue(employee.getPassword().equals(password));
		//Verify FALSE return for UNDERCASE 'open' (password is case sensitive)
		assertFalse(employee.getPassword().equals("open"));
	}
}
