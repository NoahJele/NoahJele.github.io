/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This model Suite test performs all of the
 * MedicalApplication model tests at once to ensure everything works in conjunction. 
*/
package medicalApplication.Model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class) // Run all model tests
@SuiteClasses({ TestAllergy.class, TestDoctor.class, TestEmployee.class, TestMedicalRecord.class, TestMedication.class,
		TestPatient.class, TestPatientHistory.class, TestTreatment.class })
public class AllModelTests {

}
