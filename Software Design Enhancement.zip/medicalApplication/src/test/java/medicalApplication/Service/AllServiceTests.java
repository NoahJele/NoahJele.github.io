/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This Services Suite test performs all of the
 * MedicalApplication Service tests at once to ensure everything works in conjunction. 
*/
package medicalApplication.Service;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import medical.com.medicalApplication.services.TestDoctorService;
import medical.com.medicalApplication.services.TestMedicalRecordService;

@RunWith(Suite.class) // Run all service tests
@SuiteClasses({ TestDoctorService.class, TestMedicalRecordService.class })
public class AllServiceTests {

}
