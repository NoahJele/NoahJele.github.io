package medical.com.medicalApplication;

//Imports
import java.util.Scanner;
import medical.com.medicalApplication.util.MainMenu;

public class App {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); // Initialize Scanner
		MainMenu mainmenu = new MainMenu(); // Reference the MainMenu class
		mainmenu.enterMainMenu(scanner); // Reference the enterMainMenu method
	}
}

