/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit Service test serves to test the relevant
 * methods in the DoctorService.java file. Beyond testing what
 * is already there, it also creates a new method, getDoctor(), in order
 * to be modular and reusable (in case the app was adjusted to need to return a SPECIFIC doctor).
 * To follow the Final Project Test Plan, testAddDoctor() specifically verifies that a doctor CANNOT be added
 * if their ID is identical to a previously added one
 * 
*/
package medical.com.medicalApplication.services;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestDoctorService {
	private DoctorService doctorService;
	private String name;
	private String id;
	
	//Setup necessary parameters
	@Before
	public void setup() throws Exception {
		this.doctorService = new DoctorService();
		this.name = "Noah";
		this.id = "100";
		DoctorService.getReference().addDoctor(name, id);
	}
	
	@Test
	@SuppressWarnings("static-access")
	public void testGetReference() { 
		//Prevents need to instantiate new objects
		assertEquals(doctorService.getReference(), DoctorService.getReference());
	}
	
	//Test to verify doctors can be added, but NOT if the ID is a duplicate
	@Test
	public void testAddDoctor() {
		//Should return True because ID 101 isn't used yet
		assertTrue(DoctorService.getReference().addDoctor("Billy", "101"));
		//Should return False because the ID is already initialized (in @Before)
		assertFalse(DoctorService.getReference().addDoctor("Abraham", "100"));
	}
	
	/*New method getDoctor to follow best practices (to be modular)
	  Gets specific doctor ID and name*/
	@Test
	public void testGetDoctor() {
		//Verify ID is correct
		assertTrue(DoctorService.getReference().getDoctor(id).getId().equals(id));
		assertFalse(DoctorService.getReference().getDoctor(id).getId().equals("500"));
		//Verify name is correct
		assertTrue(DoctorService.getReference().getDoctor(id).getName().equals(name));	
		assertFalse(DoctorService.getReference().getDoctor(id).getName().equals("Nick"));
	}
	
	//Test to make sure size of getAllDoctors is accurate
	@Test
	public void testGetAllDoctors() {
		//One doctor has been initialized in @Before
		assertTrue(doctorService.getAllDoctors().size() == 1);
		//Add another doctor to the list
		doctorService.addDoctor("Nick", "102");
		//Verify new size is 2
		assertTrue(doctorService.getAllDoctors().size() == 2);
		// Verify size isn't 3
		assertFalse(doctorService.getAllDoctors().size() == 3);
	}
}
