package medical.com.medicalApplication.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Patient;
/**
 * 
 * This class uses a singleton pattern to mock a service instead of using dependency injection
 * 
 * In addition, it stores data in memory only using Lists
 *
 */
public class MedicalRecordService {
	private static MedicalRecordService reference = new MedicalRecordService(); // Create references and initiate lists
	private List<Patient> patients;
	private List<MedicalRecord> medicalRecords;

	public static MedicalRecordService getReference() { // Return reference
		return reference;
	}

	MedicalRecordService() {
		this.patients = new ArrayList<Patient>(); // Initiate arraylists
		this.medicalRecords = new ArrayList<MedicalRecord>();
	}

	public boolean addPatient(String name, String id) { // Logic to add a patient
		boolean patientAdded = !patients.stream().anyMatch(patient -> patient.getId().equals(id));
		if (patientAdded) { // If the patient is added...
			Patient newPatient = new Patient(name, id); 
			patients.add(newPatient); // Add the patient to the patients list
			medicalRecords.add(new MedicalRecord(newPatient)); // Add the patient to the medical record
		}
		return patientAdded; 
	}
	
	public MedicalRecord getMedicalRecord(String patientId) { // Logic to get the medical record
		return medicalRecords.stream().filter(medicalRecord -> medicalRecord.getPatient().getId().equals(patientId)).findFirst().get();
	}

	public Patient getPatient(String patientId) { // Logic to get the patientID
		return patients.stream().filter(person -> person.getId().equals(patientId)).findFirst().get();
	}

	public List<Patient> getAllPatients() { // Logic to get all patients by returning the patients list
		if (patients.size() == 0) { // Print 'no patients found' if the patient list is 0
			System.out.println("No patients found."); 
		}  
		return patients;
	}
	
	public List<Patient> getPatientsWithAllergies(String allergyName){ // Logic to get all patients with an allergy
		for(Patient patient : getAllPatients()) { // Look at ALL patients and filter by those who have have the same allergy
			if(getMedicalRecord(patient.getId()).getHistory().getAlergies().stream().filter(allergy -> allergy.getName().equals(allergyName)).findFirst().isPresent()) {
				return Collections.singletonList(patient); // Print out all patients with the allergy
			}
		}
		return Collections.emptyList();
	}
}
