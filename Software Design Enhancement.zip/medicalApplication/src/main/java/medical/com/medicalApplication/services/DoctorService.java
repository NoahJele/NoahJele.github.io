package medical.com.medicalApplication.services;

import java.util.ArrayList;
import java.util.List;

import medical.com.medicalApplication.model.Doctor;
/**
 * 
 * This class uses a singleton pattern to mock a service instead of using dependency injection
 * 
 * In addition, it stores data in memory only using Lists
 *
 */
public class DoctorService {
	private static DoctorService reference = new DoctorService(); // Create a reference
	private static List<Doctor> doctors; // List of doctors
	
	 DoctorService(){
		doctors = new ArrayList<Doctor>(); // Array of doctors
	}
	 
	public static DoctorService getReference(){
		return reference;
	}
	
	public List<Doctor> getAllDoctors(){
		if (doctors.size() == 0) { // If doctor list = 0 print this message
			System.out.println("No Doctors Found.");
		}
		return doctors; // Return all doctors
	}
	
	public boolean addDoctor(String name, String id){
		String tempId = new String(id);
		boolean createDoctor = !doctors.stream().anyMatch(doctor -> doctor.getId().equals(tempId));
		if (createDoctor) { // Logic to add a doctor
			doctors.add(new Doctor(name, id));
		}
		return createDoctor;
	}
	
	//Create new method to getDoctor
	public Doctor getDoctor(String doctorId) {
		return doctors.stream().filter(doctor -> doctor.getId().equals(doctorId)).findFirst().get();
	}
}
