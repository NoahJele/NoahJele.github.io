package medical.com.medicalApplication.model;

/**
 * 
 * 
 * This class represents a medical record model in the system
 *
 */
public class MedicalRecord {
	
	private Patient patient;
	private PatientHistory history;
	
	
	public MedicalRecord(Patient patient) { // Define patient and an instance of PatientHistory()
		super();
		this.patient = patient;
		this.history = new PatientHistory();
	}

	public Patient getPatient() { // Return patient
		return patient;
	}

	public PatientHistory getHistory() { // Return history
		return history;
	}
	
}
