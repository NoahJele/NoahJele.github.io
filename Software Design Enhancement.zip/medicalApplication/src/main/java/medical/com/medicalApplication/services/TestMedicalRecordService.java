/**#Noah Jeleniewski
 * #CourseID: CS 320
 * #Date: 6/1/20
 * Description: This JUnit Service test verifies the various methods located in 
 * MedicalRescordService.java. Specifically, it creates new patients to verify AddPatient,
 * GetMedicalRecord, GetPatient, GetAllPatients, and GetPatientsWithAllergies. 
 * BUG: The service that this test SHOULD be named MedicalRecordService.java, NOT MedicalRescordService.java.
 * This could cause issues if people aren't paying attention!
 * BUG: In MedicalRescordService.java, for getPatientsWithAllergies,
 * the if statement has a bad comparison, comparing to NULL. I changed the behavior to:
 * if(getMedicalRecord(patient.getId()).getHistory().getAlergies().stream().filter(allergy -> allergy.getName().equals(allergyName)).findFirst().isPresent()) {*			
 * return Collections.singletonList(patient); }
 * This fixed the bug. 	
*/
package medical.com.medicalApplication.services;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;

public class TestMedicalRecordService {
	private MedicalRecordService medicalRescordService;
	private String name;
	private String id;
	private String allergicName;
	private String allergicId;

	@Before
	public void setUp() throws Exception {
		this.medicalRescordService = new MedicalRecordService();
		this.name = "Bernie";
		this.id = "210";
		medicalRescordService.addPatient(name, id);
		
		//These variables are called in testGetPatientsWithAllergies
		this.allergicName = "Megan";
		this.allergicId = "1";
		
	}

	@Test
	@SuppressWarnings("static-access")
	public void testGetReference() {
		//Prevents need to instantiate new objects
		assertEquals(medicalRescordService.getReference(), MedicalRecordService.getReference());
	}

	@Test
	public void testAddPatient() {
		// Initially succeeds as the initialized array list is empty
		assertTrue(medicalRescordService.addPatient("Gary", "1234"));
		// Should return false as an object with that ID already exists
		assertFalse(medicalRescordService.addPatient("Test", "1234"));
	}

	@Test
	public void testGetMedicalRecord() {
		//Verify name is accurate for a specific ID
		assertTrue(medicalRescordService.getMedicalRecord(id).getPatient().getName().equals(name));
	}

	@Test
	public void testGetPatient() {
		//Verify correct name
		assertTrue(medicalRescordService.getPatient(id).getName().equals(name));
		//Verify correct ID
		assertTrue(medicalRescordService.getPatient(id).getId().equals(id));
	}

	@Test
	public void testGetAllPatients() {
		//Already have two patients, so start with size() == 1
		assertTrue(medicalRescordService.getAllPatients().size() == 1);
		//Add another patient
		medicalRescordService.addPatient("Aaron", "213");
		//Verify getAllPatients.size() == 3 after adding another patient
		assertTrue(medicalRescordService.getAllPatients().size() == 2);
	}

	@Test
	public void testGetPatientsWithAllergies() {
		//Initiate new patient with allergy
		Allergy allergy = new Allergy("Cats");
		medicalRescordService.addPatient(this.allergicName,this.allergicId);
		//Add allergy
		medicalRescordService.getMedicalRecord(this.allergicId).getHistory().addAllergy(allergy);
		//Verify size of patients with 'cats' allergy is 1
		assertTrue(medicalRescordService.getPatientsWithAllergies("Cats").size() == 1);
	}

}
