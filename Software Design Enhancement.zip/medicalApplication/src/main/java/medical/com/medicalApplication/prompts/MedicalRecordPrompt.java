package medical.com.medicalApplication.prompts;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import medical.com.medicalApplication.model.Allergy;
import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.model.Treatment;
import medical.com.medicalApplication.services.DoctorService;
import medical.com.medicalApplication.services.MedicalRecordService;
import medical.com.medicalApplication.util.MenuUtil;
import medical.com.medicalApplication.util.Pair;
import medical.com.medicalApplication.util.MainMenu;
/**
 * 
 * This class creates the prompts for the medical application
 *
 */
public class MedicalRecordPrompt { // Print the menu
	private static List<String> prompt = Arrays.asList("","Medical Record Menu", "1 Add a Treatment", "2 Add a Medication",
			"3 Print Patient's Treatments", "4 Print Patient's Medications", "5 Add Allergy", "6 Print Allergies", "0 Main Menu");
	public void mainPrompt(Scanner scanner) {
		int input = -1;
		MainMenu mainmenu = new MainMenu();
		System.out.println("Enter Patient ID:"); //Prompt user for the patient ID
		String patientId = scanner.next();
		Patient patient = MedicalRecordService.getReference().getPatient(patientId);
		
		if (patient != null) { // If the patient exists
			while (true) {
				System.out.println("Patient: " + patient.getName()); // Patient name
				prompt.stream().forEach(System.out::println);
				try {
					input = scanner.nextInt(); // Get input from the user
					}catch(Exception exception)
					{ 
					break;
					}

				switch (input) {
				case 1: // Case to add treatment
					addTreatment(scanner, patient.getId());
					break;
				case 2: // Case to add medication
					addMedication(scanner, patient.getId());
					break;
				case 3: // Case to get all treatments
					MedicalRecordService.getReference().getMedicalRecord(patientId).getHistory().getAllTreatments()
							.forEach(System.out::println);
					break;
				case 4: // Case to get all medications
					MedicalRecordService.getReference().getMedicalRecord(patientId).getHistory().getAllMedications()
							.forEach(System.out::println);
					break;
				case 5: // Case to add allergy
					addAllergy(scanner, patient.getId());
					break;
				case 6: // Case to get all allergies
					MedicalRecordService.getReference().getMedicalRecord(patientId).getHistory().getAlergies()
							.forEach(System.out::println);
					break;
				case 0: // Case to leave the medical record menu
					mainmenu.enterMainMenu(scanner);
					break;
				default: // Default case
					break;
				}
			}
		} else { // If patient doesn't exist
			System.out.println("Patient with that ID could not be found");
		}
	}

	private void addAllergy(Scanner scanner, String patientId) { // Method to add an allergy
		int input = -1; 

		while (input != 0) {
			System.out.println("Enter Allergy:"); // Enter allergy name
			String allergyName = scanner.next(); // Get input

			Allergy allergy = new Allergy(allergyName);
			MedicalRecord medicalRecord = MedicalRecordService.getReference().getMedicalRecord(patientId);

			if (medicalRecord != null) { // If medical record isn't empty, add the allergy
				medicalRecord.getHistory().addAllergy(allergy);
			} else { // Else, print this message
				System.err.println("Error! Medical Record is null");
			}
			// Ask the user if they want to add another allergy
			System.out.println("Would you like to add another Allergy?\n 1 for Yes\n 0 To return to the Medical Record Menu");
			try {
				input = scanner.nextInt(); // Get input from the user
				}catch(Exception exception)
				{	break;
				}
		}		
	}

	public void addTreatment(Scanner scanner, String patientId) { // Method to add a treatment
		int input = -1;

		while (input != 0) { // Ask for treatment date, diagnosis, and description
			System.out.println("Enter the treatment date:");
			String treatmentDate = scanner.next();

			System.out.println("Enter diagnose:");
			String diagnose = scanner.next();

			System.out.println("Enter description:");
			String description = scanner.next();

			Treatment treatment = new Treatment(treatmentDate, diagnose, description); // Add the treatment to Treatment();
			MedicalRecord medicalRecord = MedicalRecordService.getReference().getMedicalRecord(patientId);

			if (medicalRecord != null) { // If medical record isn't null, add the treatment
				medicalRecord.getHistory().addTreatment(treatment);
			} else { // Else, print this message
				System.err.println("Error! Medical Record is null");
			}
			// Ask the user if they want to add another treatment
			System.out.println("Would you like to add another Treatment?\n 1 for Yes\n 0 To return to the Medical Record Menu");
			try {
				input = scanner.nextInt(); // Get input from the user
				}catch(Exception exception){	
				 break;
				}
		}
	}

	public List<Patient> findAllPatientsWithAllergy(Scanner scanner){ // Method to find all patients with a specific allergy
		System.out.println("Enter Allergy:");
		String allergy = scanner.next();
		return MedicalRecordService.getReference().getPatientsWithAllergies(allergy); // Returns patients with allergy
	}
	
	public void addMedication(Scanner scanner, String patientId) { // Method to add a medication
		int input = -1;

		while (input != 0) { // Prompt user for medication name, startDate, endDate, and dose
			System.out.println("Enter medication name:");
			String name = scanner.next();
			System.out.println("Enter startDate:");
			String startDate = scanner.next();
			System.out.println("Enter endDate:");
			String endDate = scanner.next();
			System.out.println("Enter dose:");
			String dose = scanner.next();

			Medication medication = new Medication(name, startDate, endDate, dose); // Add the medication to Medication();
			MedicalRecord medicalRecord = MedicalRecordService.getReference().getMedicalRecord(patientId);

			if (medicalRecord != null) { // If medical record isn't null, add the medication
				medicalRecord.getHistory().addMedication(medication);
			} else { // Else, print this message
				System.err.println("Error! Medical Record is null");
			}
			// Ask the user if they want to add another medication
			System.out.println("Would you like to add another Medication?\n 1 for Yes\n 0 To return to the Medical Record Menu");
			try {
				input = scanner.nextInt(); // Get input from the user
				}catch(Exception exception)
				{	break;
				}
		}
	}
		public void addPerson(boolean addDoctor, Scanner scanner) {
			int input = -1;
			String person = addDoctor ? "Doctor" : "Patient";

			while (input != 0) { // Ask for name and ID
				Pair response = MenuUtil.createTwoItemMenu(scanner, "Enter Name:", "Enter ID:");
				boolean personAdded = false;

				if (addDoctor) { // Add doctor or patient
					personAdded = DoctorService.getReference().addDoctor(response.getOne(), response.getTwo());
				} else {
					personAdded = MedicalRecordService.getReference().addPatient(response.getOne(), response.getTwo());
				}

				if (personAdded) { // Either the person is added or they are denied IF there is a duplicate ID
					System.out.println(person + " " + response.getOne() + " was succesfully added\n");
				} else {
					System.out.println(person + " " + response.getOne() + " Could not be added, duplicate ID\n");
				}
				// Ask user if they want to add another patient/doctor
				System.out.println("Would you like to add another " + person + "?\n 1 for Yes\n 0 To return to the Main Menu");
				try {
					input = scanner.nextInt(); // Get input from the user
					}catch(Exception exception)
					{	break;
			}
		}
	}
}

