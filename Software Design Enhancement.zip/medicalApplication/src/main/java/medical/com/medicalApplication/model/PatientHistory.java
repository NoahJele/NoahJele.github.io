package medical.com.medicalApplication.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * This class represents a patient history model in the system
 *
 */
public class PatientHistory {
	
	private List<Treatment> treatments;
	private List<Medication> medications;
	private List<Allergy> allergy;

	public PatientHistory() {
		
		this.treatments = new ArrayList<Treatment>(); // Define arrays of Treatment, Medication, and Allergy
		this.medications = new ArrayList<Medication>();
		this.allergy = new ArrayList<Allergy>();
	}

	public void addTreatment(Treatment treatment) {
		treatments.add(treatment); // Add treatment
	}

	public void addAllergy(Allergy allegry) {
		allergy.add(allegry); // Add allergy
	}

	public void addMedication(Medication medication) {
		if(treatments.isEmpty()) { // Specific case for if a treatment doesn't already exist
			System.out.println("No treatments have been added! Error!");
		}
		else { // Add medication if treatment exists
			medications.add(medication);
		}
	}

	public List<Allergy> getAlergies() {
		return allergy; // Return allergy
	}

	public List<Treatment> getAllTreatments() {
		return treatments; // Return treatment
	}

	public List<Medication> getAllMedications() {
		return medications; // Return medication
	}

}

