package medical.com.medicalApplication.util;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import medical.com.medicalApplication.model.Employee;
import medical.com.medicalApplication.prompts.MedicalRecordPrompt;
import medical.com.medicalApplication.services.DoctorService;
import medical.com.medicalApplication.services.MedicalRecordService;

public class MainMenu {
	private static List<String> mainMenu = Arrays.asList("", "Main Menu", "Please select from the following options",
			"1 Print Patient List", "2 Print Doctor List", "3 Add a Doctor", "4 Add a Patient", "5 Medical Records",
			"6 Search for Allergies", "0 to Exit");
	
	public void enterMainMenu(Scanner scanner) {
		// Create test employee
		Employee employee = new Employee("Mike", "1111");
		// Read console input
		scanner.useDelimiter(System.getProperty("line.separator"));
		
		// password is Open (CASE SENSITIVE)
		int passwordAttempts = 3; // User has 3 attempts to login
		String password = null; // Initialize password string to null
		boolean loginSuccess = false; // Initialize boolean loginsuccess to false
		
		System.out.println("Enter the password to log in: ");//Login loop
		while (passwordAttempts > 0 && !loginSuccess) { // While trying to login...
			password = scanner.next();
			loginSuccess = employee.getPassword().equals(password); 
			if (loginSuccess == false) { //Decrements password attempts and prints out # of attempts left IF password is invalid 
				passwordAttempts--;
				System.out.println("Incorrect password. You have " + passwordAttempts + " attempt(s) remaining");	
			}			
		}

		if (loginSuccess) { //If the user enters the correct password
			MedicalRecordPrompt medicalRecordPrompt = new MedicalRecordPrompt(); // Get the MedicalRecordPrompt class
			int input = -1;
			System.out.println("Welcome to Mercy Hospital System");
			while (input != 0) { // While the user doesn't enter 0 to exit
				mainMenu.stream().forEach(System.out::println); // Print the main menu
				try {
					input = scanner.nextInt(); // Get input from the user
					}catch(Exception exception)
					{  	System.out.println("This is not an integer. Exiting program..."); // Catch exception for non-int value
						break;
					}

				switch (input) {
				case 1: // Case 1 gets all patients
					MedicalRecordService.getReference().getAllPatients().forEach(System.out::println);
					break;
				case 2: // Case 2 gets all doctors
					DoctorService.getReference().getAllDoctors().forEach(System.out::println);
					break;
				case 3: // Case 3 is to add a doctor
					medicalRecordPrompt.addPerson(true, scanner);
					break;
				case 4: // Case 4 adds a patient (they both use addPerson)
					medicalRecordPrompt.addPerson(false, scanner);
					break;
				case 5: // Case 5 is to find a medical record
					medicalRecordPrompt.mainPrompt(scanner);
					break;
				case 6: // Case 6 is to search for an allergy
					medicalRecordPrompt.findAllPatientsWithAllergy(scanner).forEach(System.out::println);
					break;
				case 0: // Case 0 exits the program
					System.out.println("Good bye!");
					break;
				default: // Default case
					break;
				}
			}
			scanner.close(); // Close the scanner
		}else{
			System.out.println("Entered the wrong password too many times. Exiting program..."); // If password is incorrect after 3 attempts, exit program
		}		
	}
}